#!/bin/bash
for k in {1201..1300}
do
./molscat-basic <$k> $k.out
done
