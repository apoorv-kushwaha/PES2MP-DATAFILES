#!/bin/bash
for k in {1501..1600}
do
./molscat-basic <$k> $k.out
done
