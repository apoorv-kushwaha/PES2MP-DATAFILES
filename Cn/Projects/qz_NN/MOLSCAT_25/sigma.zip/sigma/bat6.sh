#!/bin/bash
for k in {1401..1500}
do
./molscat-basic <$k> $k.out
done
