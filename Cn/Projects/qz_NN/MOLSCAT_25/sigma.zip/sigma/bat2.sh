#!/bin/bash
for k in {501..900}
do
./molscat-basic <$k> $k.out
done
