#!/bin/bash
for k in {1301..1400}
do
./molscat-basic <$k> $k.out
done
