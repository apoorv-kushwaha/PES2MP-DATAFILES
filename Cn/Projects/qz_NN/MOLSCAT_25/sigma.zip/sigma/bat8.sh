#!/bin/bash
for k in {1601..1650}
do
./molscat-basic <$k> $k.out
done
