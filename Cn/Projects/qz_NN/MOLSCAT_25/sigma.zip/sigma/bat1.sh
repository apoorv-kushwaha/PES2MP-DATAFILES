#!/bin/bash
for k in {1..500}
do
./molscat-basic <$k> $k.out
done
