#!/bin/bash
for k in {901..1200}
do
./molscat-basic <$k> $k.out
done
