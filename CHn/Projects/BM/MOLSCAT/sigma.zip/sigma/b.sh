#!/bin/bash
for k in 548
do
./molscat-basic <$k> $k.out
done
